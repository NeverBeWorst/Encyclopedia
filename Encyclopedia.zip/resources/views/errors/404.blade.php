@extends('layout.app')

@section('style')
{{asset('css/404.css')}}
@endsection

@section('pagename')
Страница не найдена
@endsection

@section('content')
<h1>Страница не найдена</h1>
@endsection