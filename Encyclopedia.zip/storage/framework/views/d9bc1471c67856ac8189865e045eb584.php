<header>
    <div><h1><?php echo $__env->yieldContent('pagename'); ?></h1></div>
    
    <ul>
        <li><a href="<?php echo e(route('home')); ?>">Главная</a></li>
        <li><a href="<?php echo e(route('gallery')); ?>">Галарея</a></li>
        <li><a href="<?php echo e(route('profile')); ?>">Профиль</a></li>
        <li>
            <?php if(!auth()->user()): ?>  
                <a href="<?php echo e(route('login')); ?>">Войти</a>  
            
            <?php else: ?> 
                <a href="<?php echo e(route('login.logout')); ?>">Выйти</a> 
            <?php endif; ?> 
        </li>
    </ul>
</header><?php /**PATH W:\domains\Encyclopedia\resources\views/inc/header.blade.php ENDPATH**/ ?>