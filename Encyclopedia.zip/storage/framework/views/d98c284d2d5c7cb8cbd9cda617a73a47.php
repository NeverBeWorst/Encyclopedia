

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/login.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Авторизация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="">
        <h1 class="">Авторизация</h1>
        <form action="<?php echo e(route('login.submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="">
                <label>Логин</label>
                <input type="text" name="login" class="" placeholder="Введите имя" minlength="2" maxlength="32" required>
            </div>

            <div class="">
                <label>Пароль</label>
                <input type="password" name="password" class="" placeholder="Введите пароль" minlength="6" maxlength="32" required>
            </div>

            <input type="submit" class="" value="Авторизоваться">
        </form>
        <a href="">Забыли пароль?</a>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/login.blade.php ENDPATH**/ ?>