

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/gallery.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Галерея
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<section>
    <div class="filtration">
        <form action="<?php echo e(route ('search')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="first_filtration">
                <div class="select_block">
                    <div>
                        <p>Выберите какая мифология вам нужна</p>
                        <select  name="mythology" id="mythology" placeholder="Выбирите мифологию">
                            <option value="" selected disabled hidden>Мифология</option>
                            <?php $__currentLoopData = $_mythology; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($criterion); ?>" <?php if($criterion == $mythology): ?> selected <?php endif; ?> ><?php echo e($criterion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <p>Выберите какая местоность вам нужна</p>
                        <select name="habitat" id="habitat" placeholder="Выбирите место проживания сущности">
                            <option value="" selected disabled hidden>Среда обитания</option>
                            <?php $__currentLoopData = $_habitat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($criterion); ?>"  <?php if($criterion == $habitat): ?> selected <?php endif; ?> ><?php echo e($criterion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="creature_name">
                    <p>Введите имя нужной вам сущности</p>
                    <input  type="text" name="name" value="<?php echo e($name); ?>" placeholder="Введите имя">
                </div>
            </div>

            <div class="second_filtration">
                <ol class="">
                    <p>Добавить пользовательских сущностей?</p>
                    <p><input name="custom" type="radio" value="" checked>Без них</p>
                
                    <p><input name="custom" type="radio" value="with_custom">Добавить</p>
                
                    <p><input name="custom" type="radio" value="only_custom">Только пользовательские сущности</p>
                </ol>

                <input class="search" type="submit" value="Поиск">
            </div>

            
        </form>
        
        
        <div class="reset_filters">
            <a href="<?php echo e(route('gallery')); ?>" >
                <p>Сбросить фильтры</p>
            </a>
        </div>
        
    </div>

    <div class="scrapbook">
        <?php if($creatures): ?> 

        <?php $__currentLoopData = $creatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php if($creature->user): ?>
        <a href="<?php echo e(route('gallery.custom_creature', [$creature->id])); ?>"> 
            <div class="creature">
                <div class="seam">
                    <p class="name"><?php echo e($creature->name); ?></p>
                    <div class="picture"><img src="img/users/custom_creature/carts/<?php echo e($creature->img); ?>" alt="Фото/картина существа"></div> 
                    <p class="short_description"><?php echo e($creature->short_description); ?></p>
                </div>
            </div>
        </a>

        <?php else: ?>
        <a href="<?php echo e(route('gallery.creature', [$creature->id])); ?>"> 
            <div class="creature">
                <div class="seam">
                    <p class="name"><?php echo e($creature->name); ?></p>
                    <div class="picture"><img src="img/carts/<?php echo e($creature->img); ?>" alt="Фото/картина существа"></div> 
                    <p class="short_description"><?php echo e($creature->short_description); ?></p>
                </div>
            </div>
        </a>
        <?php endif; ?>
        
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if($creatures->count() == 0): ?>
        <div><p>Ничего не найдено</p></div>
        <?php endif; ?>
    </div>

    
    
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/gallery.blade.php ENDPATH**/ ?>