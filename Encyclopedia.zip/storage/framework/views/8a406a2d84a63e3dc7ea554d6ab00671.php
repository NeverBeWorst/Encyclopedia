

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/profile.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
<?php echo e($user->login); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div>
        <?php if($user->avatar): ?>
        <img src="../../img/users/avatar/<?php echo e($user->avatar); ?>" alt="Аватар">
        <?php else: ?> 
        <img src="../../img/icons/unknown_avatar.png" alt="Аватар">
        <?php endif; ?>
        <p><?php echo e($user->login); ?></p>
    </div>

    <?php if(Auth::user()): ?>
    <div>
        <form action="<?php echo e(route('user.friend_request.submit', [ $user->id ])); ?>" method="post">
        <?php echo csrf_field(); ?>
            <button type="submit">Запрос в дружбу</button>
        </form>
    </div>
    <?php endif; ?>

    <?php if($custom_creatures): ?> 
        <ul>
        <?php $__currentLoopData = $custom_creatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <li> 
            <img src="../../img/users/custom_creature/carts/<?php echo e($creature->img); ?>" alt="">
            <div>
                <p><?php echo e($creature->name); ?></p>
                <p><?php echo e($creature->short_description); ?></p>
            </div>
            <a href="<?php echo e(route('gallery.custom_creature', [$creature->id])); ?>">
                <p>Посмотреть</p>
            </a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/user/profile.blade.php ENDPATH**/ ?>