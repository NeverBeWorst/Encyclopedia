

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/profile.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Профиль
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <div class="flex">
        <div>
            <?php if(Auth::user() ): ?>
            
            <!-- <p>Тест отправки на почту</p> -->
            <!-- <a href="">Проверить</a> -->
            <div>
            <?php if(Auth::user()->avatar): ?>
            <img class="avatar" src="../../img/users/avatar/<?php echo e(Auth::user()->avatar); ?>" alt="Аватар">     
            <?php else: ?>      
            <img class="avatar" src="../../img/icons/unknown_avatar.png" alt="Аватар">      
            <?php endif; ?>

            <form method="post" action="<?php echo e(route('user.avatar.submit')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                <input type="file" name="image"><br>
                <button type="submit">Отправить</button>
            </form>

            <p><?php echo e(Auth::user()->login); ?></p>
            
        </div>
            <div>
                <img src="" alt="">
                <p>Логин: <?php echo e(Auth::user()->login); ?></p>
                <a href="<?php echo e(route('login.logout')); ?>">Выйти</a>
            </div>

            <?php if($custom_creatures): ?> 
            <ul>
            <?php $__currentLoopData = $custom_creatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <li><?php echo e($creature->name); ?> , <?php echo e($creature->short_description); ?>

                <a href="<?php echo e(route('gallery.custom_creature', [$creature->id])); ?>">
                    <p>Посмотреть</p>
                </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>

            <br><p>Предложение дружбы:</p>
            <?php if($friends_request): ?>
                <ul>
                    <?php $__currentLoopData = $friends_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <li><?php echo e($friend->sent_from); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <br>

            <?php else: ?> 
            <p>У вас пока нет предложений дружбы</p>
            <?php endif; ?>

            <br><p>Друзья:</p>
            <?php if($friends): ?>
                <ul>
                    <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <li><?php echo e($friend->sent_from); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <br>

            <?php else: ?> 
            <p>У вас пока нет предложений дружбы</p>
            <?php endif; ?>

        
            <?php else: ?> 
            <p>Гостевой режим</p>
            <p>Зарегистрируйтесь, пожалуйста</p>
            <?php endif; ?>
        </div>

        
        <div>
            <?php if(!auth()->user()): ?>
            <a href="<?php echo e(route('login')); ?>">Авторизация</a>
            <br>
            <a href="<?php echo e(route('reg')); ?>">Регистрация</a>
            <?php endif; ?>
        </div>
        
    </div>

    <?php if(Auth::user() && Auth::user()->role == 'admin'): ?>
    <a href="<?php echo e(route('admin.main')); ?>">Страница администратора</a>
    <?php endif; ?>

    <?php if(Auth::user()): ?>
    <div>
        <ol>
            <li>
                <div><a href="<?php echo e(route('user.proposal_creature')); ?>">Предложение к добавлению</a></div>
            </li>

            <li>
                <div><a href="<?php echo e(route('user.custom_creature')); ?>">Пользовательская сущность</a></div>
            </li>
            <li></li>
        </ol>
    </div>
    <?php endif; ?>

    
    
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/profile.blade.php ENDPATH**/ ?>