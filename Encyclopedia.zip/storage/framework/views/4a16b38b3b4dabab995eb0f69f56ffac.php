

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/admin/users.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Пользователи
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="users_list">
    <div><a href="<?php echo e(route('admin.main')); ?>">
        <p>Назад</p>
    </a></div>

    <form action="<?php echo e(route('admin.users.search')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="id" placeholder="id">
        <input type="text" name="name" placeholder="Имя">
        <input type="submit" value="Найти">
    </form>
    <ol>
        <?php if($search): ?>
            <li>
                <p><?php echo e($users->id); ?></p>
                <p><?php echo e($users->login); ?></p>
                <p><?php echo e($users->email); ?></p>
                <p><?php echo e($users->created_at); ?></p>
                <p><?php echo e($users->update_at); ?></p>
                <!-- <p><a href="<?php echo e(route('admin.user_block', [$users->id])); ?>">Заблокировать</a></p> -->
                <p><form action="<?php echo e(route('admin.user_delete', [$users->id])); ?>" method="post"> <?php echo csrf_field(); ?> <input type="submit" value="Удалить"> </form></p>
            </li>
        <?php endif; ?>
        <?php if(!$search): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <p><?php echo e($user->id); ?></p>
                <p><?php echo e($user->login); ?></p>
                <p><?php echo e($user->email); ?></p>
                <p><?php echo e($user->created_at); ?></p>
                <p><?php echo e($user->update_at); ?></p>
                <!-- <p><a href="<?php echo e(route('admin.user_block', [$user->id])); ?>">Заблокировать</a></p> -->
                <p><form action="<?php echo e(route('admin.user_delete', [$user->id])); ?>" method="post"> <?php echo csrf_field(); ?> <input type="submit" value="Удалить"> </form></p>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
    </ol>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/admin/users.blade.php ENDPATH**/ ?>