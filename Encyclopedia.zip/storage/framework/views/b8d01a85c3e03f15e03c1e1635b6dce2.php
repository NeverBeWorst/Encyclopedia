<img  src="img/background.png" alt="">

<div class="main_background"></div><?php /**PATH W:\domains\Encyclopedia\resources\views/inc/background.blade.php ENDPATH**/ ?>