

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/404.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Страница не найдена
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Страница не найдена</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Apps\OSPanel\domains\Encyclopedia\resources\views/errors/404.blade.php ENDPATH**/ ?>