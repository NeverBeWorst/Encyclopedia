

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/admin/proposal_add_creature.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Предложения добавления сущности
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div >
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    
    
<?php endif; ?>

<section>
        <div><a href="<?php echo e(route('admin.main')); ?>">
            <p>Назад</p>
        </a></div>
        
        <div></div>
        <div></div>
        <div></div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/admin/proposal_add_creature.blade.php ENDPATH**/ ?>