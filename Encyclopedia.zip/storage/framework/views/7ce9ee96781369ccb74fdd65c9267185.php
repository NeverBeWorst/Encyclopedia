

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/admin/.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div>
        <img src="../../../img/users/proposal_creature/carts/<?php echo e($creature->img); ?>" alt="">
        <p><?php echo e($creature->id); ?></p>
        <p><?php echo e($creature->name); ?></p>
        <p><?php echo e($creature->mythology); ?></p>
        <p><?php echo e($creature->habitat); ?></p>
        <p><?php echo e($creature->short_description); ?></p>
        <p><?php echo e($creature->created_at); ?></p>
        <p><?php echo e($creature->description); ?></p>
        <p>---------------</p>
        <p><?php echo e($creature->status); ?></p>
        <form action="<?php echo e(route('admin.proposal_creature.confirm', [$creature->id])); ?>" method="post"> <?php echo csrf_field(); ?> <input type="submit" value="Принять"></form>
        <form action="<?php echo e(route('admin.proposal_creature.reject', [$creature->id])); ?>" method="post"> <?php echo csrf_field(); ?> <input type="submit" value="Отклонить"></form>
    </div>
</section>
<li>
        
                
            </li>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/admin/proposal_creature_view.blade.php ENDPATH**/ ?>