

<?php $__env->startSection('style'); ?>
<?php echo e(asset('')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Авторизация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    
    <?php
        $tfa = new RobThree\Auth\TwoFactorAuth('RobThree TwoFactorAuth');
        $secret = $tfa->createSecret();
        echo chunk_split($secret, 4, ' ');
        $code = $tfa->getCode($secret);
        echo "<br>";
        echo $code;
        if ($tfa->verifyCode($secret, $code ) === true) {
            echo " <br><span>OK</span>";
        }
        else {
            echo " <br><span>не</span>";
        }
    ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/password_recovery.blade.php ENDPATH**/ ?>