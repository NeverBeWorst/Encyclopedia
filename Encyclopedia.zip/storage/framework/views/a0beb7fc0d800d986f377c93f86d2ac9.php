

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/minigames/find_pair.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Найди пару
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/minigames/find_pair.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="game-container">
    <div class="cards-grid" id="cards-grid"></div>
</div>

<div>
    <form action=""></form>
</div>

<script type="text/javascript">

    function get_creature() {
        let creatures = new Array();
        let i = 0;

        <?php $__currentLoopData = $creatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        creatures[i] = '<?php echo e($creature->img); ?>';
        i++;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        return creatures;
    }
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.minigames', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/minigames/find_pair.blade.php ENDPATH**/ ?>