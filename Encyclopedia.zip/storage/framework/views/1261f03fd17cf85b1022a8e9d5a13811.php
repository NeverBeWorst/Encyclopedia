

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/admin.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Админка
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <div><h2>Форма для создания существа</h2></div><br>

    <div class="creature_form">
        <form action="<?php echo e(route('admin.creature.submit')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="form_block">
                <div>
                    <input type="text" name="name" id="name" placeholder="Введите имя" required><br>
                    <input type="text" name="img" placeholder="Введите наименование фото" required><br>
                    
                    <select name="mythology" id="mythology" placeholder="Выбирите мифологию"  required>
                        <option value="" selected disabled hidden>Мифология</option>
                        <?php $__currentLoopData = $_mythology; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($criterion); ?>" ><?php echo e($criterion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>
                    
                    <select name="habitat" id="habitat" placeholder="Выбирите место проживания сущности" required>
                        <option value="" selected disabled hidden>Среда обитания</option>
                        <?php $__currentLoopData = $_habitat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($criterion); ?>" ><?php echo e($criterion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>

                    <input type="text" name="short_description" placeholder="Введите краткое описание"><br>

                    <button type="submit">Отправить</button>
                </div>
                
                <textarea rows="10"  name="description" placeholder="Введите Описание"></textarea><br>
            </div>
        </form>

        <form method="post" action="<?php echo e(route('admin.creatures_image.submit')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 
            <div>
                <input type="text" name="img_name" placeholder="Введите как хотите назвать картинку"><br>
                <input type="file" name="image"><br>
                
                <button type="submit">Отправить</button>
            </div>

            <img class="your-image" src="" alt="">
        </form>

        <form action="<?php echo e(route('admin.creature_with_img.submit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="form_block">
                <div>
                    <input type="text" name="name" id="name" placeholder="Введите имя" required><br>
                    <input type="text" name="img_name" placeholder="Введите как хотите назвать картинку"><br>
                    <input type="file" name="image"><br>
                    
                    <select name="mythology" id="mythology" placeholder="Выбирите мифологию" required>
                        <option value="" selected disabled hidden>Мифология</option>
                        <?php $__currentLoopData = $_mythology; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($criterion); ?>" ><?php echo e($criterion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>
                    
                    
                    <select name="habitat" id="habitat" placeholder="Выбирите место проживания сущности" required>
                        <option value="" selected disabled hidden>Среда обитания</option>
                        <?php $__currentLoopData = $_habitat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($criterion); ?>" ><?php echo e($criterion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>

                    <input type="text" name="short_description" placeholder="Введите краткое описание"><br>

                    <button type="submit">Отправить</button>
                </div>
                
                <textarea rows="10"  name="description" placeholder="Введите Описание"></textarea><br>
            </div>
        </form>

        <form action=""></form>
    </div>

    <div class="users_list">
        <p><a href="<?php echo e(route('admin.users')); ?>">Пользователи</a></p>
    </div>

    <div>
        <p><a href="<?php echo e(route('admin.proposal_creature')); ?>">Список предложений к добавлению</a></p>
    </div>

    <div>
        <p><a href="<?php echo e(route('admin.custom_creature')); ?>">Список пользовательских существ</a></p>
    </div>

    <br><br><br>
    <div>
        <h2>Острожно!!!!</h2>
        <form action="<?php echo e(route('admin.refresh')); ?>" method="post"><?php echo csrf_field(); ?><input type="submit" value="СТЕРЕТЬ БАЗУ ДАННЫХ"></form>
        <form action="<?php echo e(route('admin.do_admin')); ?>" method="post"><?php echo csrf_field(); ?> <input type="text" name="name"><input type="submit" value="Добавить админа"></form>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Apps\OSPanel\domains\Encyclopedia\resources\views/admin.blade.php ENDPATH**/ ?>