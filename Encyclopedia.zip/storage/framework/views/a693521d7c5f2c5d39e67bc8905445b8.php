<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo $__env->yieldContent('style'); ?>">
    <?php echo $__env->yieldContent('extra_style'); ?>
    <title><?php echo $__env->yieldContent('pagename'); ?></title>
</head>
<body>
    <header>
        <a href="<?php echo e(route('home')); ?>">
            <p>Вернуться на главный сайт</p>
        </a>
        <h1><?php echo $__env->yieldContent('pagename'); ?></h1>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH W:\domains\Encyclopedia\resources\views/layout/minigames.blade.php ENDPATH**/ ?>