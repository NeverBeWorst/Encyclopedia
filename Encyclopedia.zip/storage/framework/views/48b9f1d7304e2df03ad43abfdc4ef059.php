

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/minigames/select.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Выбор игры
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul>
    <li>
        <a href="<?php echo e(route('minigames.find_pair')); ?>">
            <p>Найди пару</p>
        </a>
    </li>
    <li>
        <a href="">
            <p></p>
        </a>
    </li>
    <li>
        <a href="">
            <p></p>
        </a>
    </li>
    <li>
        <a href="">
            <p></p>
        </a>
    </li>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.minigames', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/minigames/select.blade.php ENDPATH**/ ?>