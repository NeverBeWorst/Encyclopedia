

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Пользовательское существо
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div>
        <form action="<?php echo e(route('user.custom_creature.submit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="form_block">
                <div>
                    <input type="text" name="name" id="name" placeholder="Введите имя" required><br>
                    <input type="file" name="image"><br>
                    
                    <select name="habitat" id="habitat" placeholder="Выбирите место проживания сущности" required>
                        <option value="" selected disabled hidden>Среда обитания</option>
                        <?php $__currentLoopData = $_habitat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($criterion); ?>" ><?php echo e($criterion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>

                    <input type="text" name="short_description" placeholder="Введите краткое описание"><br>

                    <button type="submit">Отправить</button>
                </div>
                
                <textarea rows="10"  name="description" placeholder="Введите Описание"></textarea><br>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Apps\OSPanel\domains\Encyclopedia\resources\views/user/custom_creature.blade.php ENDPATH**/ ?>