

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
Пользовательское существо
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <ul>
        <?php if($creatures): ?> 
        <?php $__currentLoopData = $creatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <img src="../../../img/users/custom_creature/carts/<?php echo e($creature->img); ?>" alt="">
            <p><?php echo e($creature->user); ?></p>
            <p><?php echo e($creature->name); ?></p>
            <p><?php echo e($creature->habitat); ?></p>
            <p><?php echo e($creature->short_description); ?></p>
            <p><?php echo e($creature->description); ?></p>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\Encyclopedia\resources\views/admin/custom_creature.blade.php ENDPATH**/ ?>