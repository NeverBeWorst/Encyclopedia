<footer class="content">
    <div>
        <p>@ Encyclopedia</p>
        <p>У нас пока что нет соц сетей. <br> Просим прощения!</p>
    </div>
    <p>2024</p>
</footer><?php /**PATH E:\Apps\OSPanel\domains\Encyclopedia\resources\views/inc/footer.blade.php ENDPATH**/ ?>