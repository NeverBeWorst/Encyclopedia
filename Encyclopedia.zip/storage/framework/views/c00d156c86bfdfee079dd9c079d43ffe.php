

<?php $__env->startSection('style'); ?>
<?php echo e(asset('css/gallery_creature.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename'); ?>
<?php echo e($creature->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="back_button">
        <a href="<?php echo e(route ('gallery')); ?>"><p>Назад</p></a>
    </div>
    
    <div class="info_block">
        <div class="picture">
            <?php if($creature->user): ?>
            <img src="../../img/users/custom_creature/carts/<?php echo e($creature->img); ?>" alt="Фото/картина существа"> 
            <a class="download_icon" href="../../img/users/custom_creature/carts/<?php echo e($creature->img); ?>" download><img src="../../img/icons/download.png" alt="Скачать"></a>

            <?php else: ?>
            <img src="../../img/carts/<?php echo e($creature->img); ?>" alt="Фото/картина существа"> 
            <a class="download_icon" href="../../<?php echo e($creature->img); ?>" download><img src="../../img/icons/download.png" alt="Скачать"></a>
            <?php endif; ?>
        </div>
        

        <div class="short_info">
            <p class="name"><?php echo e($creature->name); ?></p>
            <div><p>Мифология: </p><p><?php echo e($creature->mythology); ?></p></div>
            <div><p>Краткое сведение: </p><p class="short_description"><?php echo e($creature->short_description); ?></p></div>
            <div><p>Место обитания: </p><p><?php echo e($creature->habitat); ?></p></div>
        </div>
    </div>

    <div class="creature_description">
        <p>Основная информация: </p>
        <!-- <p class="description"><?php echo e($creature->description); ?></p> -->
        <ul class="description">
            <?php $__currentLoopData = $creature_text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($text); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="comment_block">
        <?php if(session()->get('user_name') ): ?>
        <div>
            <p>Оставьте свой коммментарий:</p>
            <form action="<?php echo e(route('gallery_creature.submit', [$creature->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label>Текст:</label>
                <br>
                <input class="text" type="text" name="text" placeholder="Введите текст">
                <br>
                <input type="submit">
            </form>
        </div>
        <?php endif; ?>

        <div class="comments">
            <p>Комментарии других пользователей:</p>

            <?php if($reviews): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <a href="<?php echo e(route('profile.user', [$review->user_id] )); ?>"><p class="user_name"><?php echo e($review->user_name); ?></p></a>
                    <p><?php echo e($review->text); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
            <p>Пока ни кто не оставлял свои комментарии</p>
            <?php endif; ?>
        </div>
        

    </div>
    
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Apps\OSPanel\domains\Encyclopedia\resources\views/gallery_creature.blade.php ENDPATH**/ ?>